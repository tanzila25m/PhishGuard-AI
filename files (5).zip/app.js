'use strict';
/* PhishGuard AI - local, deterministic phishing-indicator analysis. No network, no eval, no innerHTML. */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const h=(t,a,...c)=>{if(a==null||typeof a!=='object'||a instanceof Node||Array.isArray(a)){c.unshift(a);a={}}
 const e=document.createElement(t);for(const k in a){if(k==='class')e.className=a[k];else if(k.startsWith('on'))e.addEventListener(k.slice(2),a[k]);else e.setAttribute(k,a[k])}
 c.flat(9).forEach(x=>{if(x!=null&&x!==false)e.append(x instanceof Node?x:String(x))});return e};
const NOTICE='Local heuristic analysis only. This is not a guaranteed verdict and not an external reputation check.';
const CFG={shorteners:['bit.ly','tinyurl.com','t.co','goo.gl','is.gd','ow.ly','buff.ly','rebrand.ly','cutt.ly'],
 brands:['paypal','microsoft','google','amazon','apple','netflix','dhl','fedex','linkedin','github'],storeFull:false};

/* ---------- storage with graceful fallback ---------- */
const mem={};
const store={sim:false,ok:true,
 get(k){try{if(this.sim)throw 0;return localStorage.getItem(k)}catch(e){this.ok=false;return k in mem?mem[k]:null}},
 set(k,v){try{if(this.sim)throw 0;localStorage.setItem(k,v)}catch(e){this.ok=false;mem[k]=v}},
 del(k){try{if(this.sim)throw 0;localStorage.removeItem(k)}catch(e){this.ok=false}delete mem[k]}};

/* ---------- rule table: ids, groups, weights (one place, easy to test) ---------- */
const R={
 'url.scheme':{n:'Non-HTTPS scheme',g:'scheme',w:6,why:'Unencrypted links can be intercepted. HTTP alone does not prove malice, and HTTPS does not prove safety.',a:'Prefer typing the known address yourself.'},
 'url.badscheme':{n:'Non-web URL scheme',g:'scheme',w:25,why:'Schemes such as javascript:, data: or file: are not normal web links.',a:'Do not click or open it.'},
 'url.ip':{n:'IP address instead of a domain',g:'host',w:20,why:'Legitimate services rarely ask users to log in at a bare IP address.',a:'Do not enter credentials; verify via an official channel.'},
 'url.long':{n:'Very long URL',g:'long',w:5,why:'Long URLs can hide the real destination or carry tracking/redirect data. Weak signal.',a:'Inspect the host portion before the first "/".'},
 'url.userinfo':{n:'User-info before the host',g:'userinfo',w:18,why:'Text before "@" is ignored for routing but can make a link look like another site.',a:'Read the host after the "@" only.'},
 'url.punycode':{n:'Punycode / non-ASCII hostname',g:'idn',w:12,why:'Look-alike characters can imitate a known domain. Many legitimate sites also use IDNs.',a:'Compare the ASCII (xn--) form with the expected domain.'},
 'url.port':{n:'Unusual port',g:'port',w:8,why:'Phishing kits sometimes run on non-standard ports. Some legitimate services do too.',a:'Confirm the service really uses this port.'},
 'url.subdomain':{n:'Misleading subdomain or embedded brand',g:'brand',w:15,why:'A trusted brand name placed outside the registrable domain can mislead readers.',a:'Identify the registrable domain (the last labels before the path).'},
 'url.typo':{n:'Possible typosquatting',g:'brand',w:18,why:'The domain closely resembles a name in the small local example brand list.',a:'Compare spelling character by character with the real site.'},
 'url.encoding':{n:'Heavy or double percent-encoding',g:'enc',w:6,why:'Encoding can obscure what a URL contains. Weak signal.',a:'Decode and review it in a safe tool before use.'},
 'url.ext':{n:'Risky file extension in path',g:'ext',w:12,why:'The path points at a file type often used to deliver malware. Content was not inspected.',a:'Do not download; confirm with the sender.'},
 'url.short':{n:'URL shortener',g:'short',w:10,why:'The real destination is hidden. The shortener list is local and configurable.',a:'Ask for the full link or use a trusted expander.'},
 'url.redirect':{n:'Embedded redirect URL',g:'redir',w:8,why:'Another URL appears inside this one. Real redirects were not followed.',a:'Treat the final destination as unknown.'},
 'link.mismatch':{n:'Link text and destination mismatch',g:'mismatch',w:22,why:'The text shown to the reader names a different site than the real destination.',a:'Do not click; go to the site by typing its address.'},
 'mail.urgency':{n:'Urgency or pressure language',g:'urgency',w:8,why:'Pressure reduces careful checking. Legitimate senders also use deadlines sometimes.',a:'Pause and verify through a separate trusted channel.'},
 'mail.creds':{n:'Request for credentials or sensitive data',g:'creds',w:20,why:'Legitimate services rarely ask for passwords or codes by email.',a:'Never send these; sign in by typing the official address.'},
 'mail.payment':{n:'Payment or bank-detail change',g:'payment',w:18,why:'Changed bank details are a common fraud pattern.',a:'Confirm by phone using a number you already trust.'},
 'mail.threat':{n:'Account suspension or closure threat',g:'threat',w:14,why:'Threats of loss push readers to act before verifying.',a:'Check your account by opening the official site yourself.'},
 'mail.attach':{n:'Attachment or download request in text',g:'attach',w:8,why:'The text asks you to open or download something. Attachments were not inspected.',a:'Confirm the sender before opening anything.'},
 'mail.bypass':{n:'Request to bypass normal procedure',g:'bypass',w:14,why:'Secrecy, gift cards or skipping approval are common impersonation tactics.',a:'Follow your normal approval process.'},
 'mail.orgmismatch':{n:'Sender domain does not match claimed organization',g:'sender',w:18,why:'Organizations usually send from domains related to their name. Exceptions exist (third-party senders).',a:'Check the organization\'s real domain independently.'},
 'mail.knownmismatch':{n:'Sender domain differs from known legitimate domain',g:'sender',w:25,why:'You supplied the expected domain and the sender does not use it.',a:'Treat as unverified until confirmed.'},
 'mail.lookalike':{n:'Sender domain resembles a known name',g:'senderbrand',w:18,why:'The sender domain is spelled almost like a known domain or brand.',a:'Compare spelling carefully.'},
 'mail.replyto':{n:'Reply-To differs from sender',g:'replyto',w:15,why:'Replies would go to a different domain than the one shown as sender.',a:'Do not reply until the address is verified.'}};
const clip=(s,n=160)=>{s=String(s).replace(/\s+/g,' ').trim();return s.length>n?s.slice(0,n-1)+'…':s};
const F=(id,conf,ev,w)=>{const r=R[id];return{id,rule:r.n,group:r.g,weight:w??r.w,conf,evidence:[].concat(ev).map(x=>clip(x)),why:r.why,action:r.a}};

/* ---------- helpers ---------- */
const regDomain=host=>{const p=host.split('.');if(p.length<=2)return host;const sl=p[p.length-2];
 return(p[p.length-1].length===2&&['co','com','org','net','gov','ac','edu'].includes(sl))?p.slice(-3).join('.'):p.slice(-2).join('.')};
const lev=(a,b)=>{const d=Array.from({length:a.length+1},(_,i)=>[i]);for(let j=1;j<=b.length;j++)d[0][j]=j;
 for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++)d[i][j]=Math.min(d[i-1][j]+1,d[i][j-1]+1,d[i-1][j-1]+(a[i-1]===b[j-1]?0:1));return d[a.length][b.length]};
const norm=s=>s.toLowerCase().replace(/0/g,'o').replace(/1/g,'l').replace(/3/g,'e').replace(/5/g,'s').replace(/rn/g,'m').replace(/vv/g,'w');
function brandCheck(host){const out=[],rd=regDomain(host),rl=rd.split('.')[0],pre=host.slice(0,Math.max(0,host.length-rd.length));
 for(const b of CFG.brands){if(rl===b)continue;
  if(pre.split(/[.-]/).includes(b))out.push(['url.subdomain','"'+b+'" appears in the subdomain, but the registrable domain is '+rd]);
  else if(rl.split('-').includes(b))out.push(['url.subdomain','Registrable domain '+rd+' embeds the brand "'+b+'"']);
  else{const d=lev(rl,b);if(norm(rl)===b||(b.length>=5&&d<=1)||(b.length>=8&&d<=2))out.push(['url.typo','"'+rl+'" resembles "'+b+'" (edit distance '+d+')'])}}
 return out}

/* ---------- URL analysis ---------- */
function analyzeURL(raw,label){
 const t=String(raw||'').trim();if(!t)return{ok:false,input:t,error:'Empty input. Enter a URL to analyze.',findings:[]};
 let u=null,note='';
 try{u=new URL(t)}catch(e){if(!/^[a-z][a-z0-9+.-]*:/i.test(t)){try{u=new URL('http://'+t);note='No scheme supplied; scheme rule skipped.'}catch(e2){}}}
 if(!u)return{ok:false,input:t,error:'Could not parse as a URL. A valid URL needs a scheme and host, e.g. https://example.com/path. It was not opened.',findings:[]};
 const f=[],sch=u.protocol.replace(':',''),host=u.hostname.toLowerCase();
 const parsed={scheme:note?'(none supplied)':sch,host:host||'(none)',port:u.port||'(default)',path:clip(u.pathname+u.search,100)};
 if(!['http','https'].includes(sch)){f.push(F('url.badscheme','High','Scheme "'+sch+':"'));return{ok:true,input:t,parsed,findings:f,note}}
 if(sch==='http'&&!note)f.push(F('url.scheme','High','Scheme is http:// (not encrypted)'));
 if(/^(\d{1,3}\.){3}\d{1,3}$/.test(host)||host.startsWith('['))f.push(F('url.ip','High','Host is an IP address: '+host));
 if(t.length>100)f.push(F('url.long','Medium','Length is '+t.length+' characters'));
 if(u.username||u.password)f.push(F('url.userinfo','High','User-info "'+u.username+'@" precedes the real host '+host));
 const hp=t.replace(/^[a-z]+:\/\//i,'').split(/[/?#]/)[0];
 if(host.includes('xn--')||/[^\x00-\x7f]/.test(hp))f.push(F('url.punycode','Medium',(host.includes('xn--')?'Host has an xn-- label: ':'Host has non-ASCII characters; ASCII form: ')+host));
 if(u.port&&!['80','443'].includes(u.port))f.push(F('url.port','Medium','Port '+u.port));
 if(!/^[\d.]+$/.test(host)&&!host.startsWith('['))for(const[id,ev]of brandCheck(host))f.push(F(id,'Medium',ev));
 if(CFG.shorteners.includes(host)||CFG.shorteners.includes(regDomain(host)))f.push(F('url.short','Medium','Host '+host+' is in the local shortener list; destination unknown'));
 const enc=(t.match(/%[0-9a-f]{2}/gi)||[]).length,dbl=/%25[0-9a-f]{2}/i.test(t);
 if(enc>=6||dbl)f.push(F('url.encoding','Low',enc+' percent-encoded sequences'+(dbl?', including double encoding':'')));
 const ext=u.pathname.match(/\.(exe|scr|bat|cmd|msi|js|jar|vbs|iso|docm|xlsm|zip|rar|apk)$/i);
 if(ext)f.push(F('url.ext','Medium','Path ends with '+ext[0]));
 if(/https?(:\/\/|%3a%2f%2f)/i.test(u.search+u.pathname))f.push(F('url.redirect','Low','Another URL is embedded in the path or query; redirects were not followed'));
 if(label){const m=label.match(/(?:https?:\/\/)?((?:[a-z0-9-]+\.)+[a-z]{2,})/i);
  if(m&&regDomain(m[1].toLowerCase())!==regDomain(host))f.push(F('link.mismatch','High','Label shows "'+clip(label,60)+'" but the destination host is '+host))}
 return{ok:true,input:t,parsed,findings:f,note}}

function extractURLs(text){const out=[],map={};const re=/\b(?:https?:\/\/|www\.)[^\s<>"'\])]+/gi;let m;
 while((m=re.exec(text))){const u=m[0].replace(/[.,;:!?)]+$/,'');if(!u)continue;
  if(map[u])map[u].count++;else{map[u]={url:u,count:1,line:text.slice(0,m.index).split('\n').length};out.push(map[u])}}return out}
function linkPairs(text){const p=[];let m;const a=/<a\s[^>]*href\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
 while((m=a.exec(text)))p.push([m[1],m[2].replace(/<[^>]*>/g,'')]);
 const md=/\[([^\]]+)\]\((https?:[^)\s]+)\)/g;while((m=md.exec(text)))p.push([m[2],m[1]]);return p}

/* ---------- scoring ---------- */
function combine(list){const g={};for(const f of list){const c=g[f.group];
 if(!c)g[f.group]={...f,evidence:[...f.evidence]};
 else if(f.weight>c.weight){const ev=c.evidence;Object.assign(c,f,{evidence:[...f.evidence,...ev]})}else c.evidence.push(...f.evidence)}
 const out=Object.values(g).map(f=>({...f,evidence:[...new Set(f.evidence)].slice(0,4)})).sort((a,b)=>b.weight-a.weight||a.id.localeCompare(b.id));
 return{findings:out,score:Math.min(100,out.reduce((s,f)=>s+f.weight,0))}}
const BANDS=[[25,'Lower observed risk','ok'],[50,'Caution','cau'],[75,'High concern','hi'],[101,'Very high concern','vh']];
const bandOf=s=>BANDS.find(b=>s<b[0]);
const verdictOf=(s,insuff,n)=>insuff?'Insufficient information to assess reliably':s<25?'No strong phishing indicators found':(s>=50&&n>=2)?'High concern: multiple warning signs found':'Suspicious indicators detected';
const UNKNOWN=['Whether any remote site is currently malicious (no live lookup performed)','Domain registration age and reputation','Actual redirect destinations and server behavior','Whether a site steals credentials or a file contains malware','SPF, DKIM and DMARC results (no raw headers were supplied or verified)','Whether the sender account itself is compromised'];
let seq=0;const newId=()=>'PG-'+Date.now().toString(36).toUpperCase()+'-'+(++seq);
function finish(type,list,ctx){const c=combine(list),b=bandOf(c.score);
 return{id:newId(),ts:new Date().toISOString(),type,score:c.score,band:b[1],bandCls:b[2],verdict:verdictOf(c.score,ctx.insuff,c.findings.length),
 confidence:ctx.conf,findings:c.findings,urls:ctx.urls||[],facts:ctx.facts,unknowns:UNKNOWN,
 steps:c.score>=25?['Do not click links, open attachments, or reply with sensitive data.','Verify through a separate channel you already trust (typed address, known phone number).','Report it to your IT team, school, or email provider.']:['No strong indicators does not mean safe. Verify unexpected requests independently.','Keep software and filters up to date.']}}

/* ---------- email analysis ---------- */
const PAT=[['mail.urgency',/\b(urgent(ly)?|immediately|right away|act now|final notice|asap|within \d+ ?(hours?|minutes?|hrs?)|expires? (today|soon|tonight)|last warning)\b/gi],
['mail.creds',/\b(password|passcode|verification code|one[- ]time (code|password)|otp|pin|social security|ssn|card number|cvv|security code|login credentials)\b/gi],
['mail.payment',/\b((new|updated|changed?|different) (bank|account|payment|banking) (details|number|information)|(change|update) (our|the|my) (bank|payment)\w*|wire (the )?(funds|payment|money))\b/gi],
['mail.threat',/\b(account (will be |has been |is )?(suspended|locked|closed|deactivated|terminated|disabled)|(suspend|suspension|deactivat|terminat)\w* (of )?(your )?account|permanently (closed|deleted))\b/gi],
['mail.attach',/\b((see|open|view) (the )?attach(ed|ment)|attached (file|document|invoice)|download (the|this|your) (file|document|attachment|invoice)|enable (macros|content))\b/gi],
['mail.bypass',/\b(gift cards?|(don'?t|do not) (tell|inform|share)|keep (this|it) (confidential|secret|between us)|bypass|skip (the )?(usual|normal|standard) (process|procedure|approval)|without (telling|approval|informing))\b/gi]];
function analyzeEmail(f){
 const subj=(f.subject||'').trim(),body=(f.body||'').trim(),txt=subj+'\n'+body;
 if(!txt.trim())return{error:'Enter a subject or body to analyze.'};
 const L=[],facts=[];
 for(const[id,re]of PAT){const ms=[...txt.matchAll(re)].map(m=>m[0]);
  if(ms.length){const ev=[...new Set(ms.map(x=>x.toLowerCase()))].slice(0,3).map(x=>'Text contains "'+x+'"');
   L.push(F(id,id==='mail.urgency'&&ms.length<2?'Low':'Medium',ev,id==='mail.urgency'&&ms.length>=3?12:undefined))}}
 const addr=(f.addr||'').trim().toLowerCase(),sd=addr.includes('@')?addr.split('@').pop():'',known=(f.known||'').trim().toLowerCase(),
  org=(f.org||'').toLowerCase().replace(/[^a-z0-9]/g,''),rep=(f.reply||'').trim().toLowerCase();
 facts.push(addr?(sd?'Sender domain supplied: '+sd:'Sender address supplied but has no valid domain: '+clip(addr,60)):'No sender address supplied');
 if(known&&sd&&sd!==known&&!sd.endsWith('.'+known))L.push(F('mail.knownmismatch','High','Sender domain '+sd+' differs from the known legitimate domain '+known));
 else if(org&&sd&&!known&&!regDomain(sd).replace(/[^a-z0-9]/g,'').includes(org))L.push(F('mail.orgmismatch','Medium','Claimed organization "'+clip(f.org,40)+'" is not reflected in sender domain '+sd));
 if(sd){for(const[,ev]of brandCheck(sd).slice(0,1))L.push(F('mail.lookalike','Medium','Sender domain: '+ev));
  if(known){const a=regDomain(sd).split('.')[0],b=regDomain(known).split('.')[0];if(a!==b&&lev(a,b)<=2)L.push(F('mail.lookalike','Medium','Sender label "'+a+'" is within 2 edits of "'+b+'"'))}}
 if(rep){const rd=rep.split('@').pop();facts.push('Reply-To supplied: '+rd);if(sd&&regDomain(rd)!==regDomain(sd))L.push(F('mail.replyto','High','Reply-To domain '+rd+' differs from sender domain '+sd))}else facts.push('No Reply-To supplied');
 const urls=extractURLs(txt);facts.push(urls.length+' URL(s) extracted; '+urls.reduce((s,u)=>s+u.count,0)+' occurrence(s)');
 for(const u of urls){const r=analyzeURL(u.url);u.ok=r.ok;u.error=r.error;u.parsed=r.parsed;u.findings=r.findings.map(x=>x.rule);if(r.ok)L.push(...r.findings.map(x=>({...x,evidence:x.evidence.map(e=>clip(e))})));else facts.push('Malformed link not scored: '+clip(u.url,60))}
 for(const[href,lab]of linkPairs(txt)){const r=analyzeURL(href,lab);L.push(...r.findings.filter(x=>x.id==='link.mismatch'))}
 facts.push('Body length: '+body.length+' characters. Raw headers supplied: no (SPF/DKIM/DMARC not verified)');
 const c=combine(L),insuff=txt.trim().length<25||(c.score<25&&!addr&&body.length<120);
 const conf=(addr&&body.length>=80)?'Moderate (sender and body supplied; no headers)':body.length>=40?'Low (limited input)':'Very low (little input)';
 return finish('email',L,{insuff,conf,facts,urls})}
function urlAnalysis(raw,label){const r=analyzeURL(raw,label);if(!r.ok)return{error:r.error};
 const p=r.parsed,facts=['Scheme: '+p.scheme,'Host: '+p.host,'Port: '+p.port,'Path/query: '+p.path];if(r.note)facts.push(r.note);
 const a=finish('url',r.findings,{insuff:false,conf:'Low to moderate (text-only; no live data)',facts,urls:[{url:r.input,count:1,line:1,ok:true,parsed:p,findings:r.findings.map(x=>x.rule)}]});return a}

/* ---------- reports ---------- */
const report=a=>({tool:'PhishGuard AI (local deterministic rules, no AI model)',notice:NOTICE,analysisId:a.id,timestamp:a.ts,inputType:a.type,riskScore:a.score,band:a.band,verdict:a.verdict,confidence:a.confidence,
 ruleResults:a.findings.map(f=>({id:f.id,rule:f.rule,contribution:f.weight,confidence:f.conf,evidenceExcerpts:f.evidence,whyItMatters:f.why,recommendedAction:f.action})),
 extractedUrls:a.urls.map(u=>({url:u.url,occurrences:u.count,line:u.line,findings:u.findings||[]})),observedFacts:a.facts,unverifiedClaimsAndLimitations:a.unknowns,recommendedActions:a.steps,
 finalAssessment:a.verdict+' (score '+a.score+'/100, '+a.band+'). '+NOTICE});
const me=s=>String(s).replace(/[\\`*_{}\[\]<>#|]/g,'\\$&'),cs=s=>'`'+String(s).replace(/`/g,"'")+'`';
function toMD(r){const L=['# PhishGuard AI Report','','> **'+me(r.notice)+'**','','- Analysis ID: '+me(r.analysisId),'- Timestamp: '+me(r.timestamp),'- Input type: '+me(r.inputType),'- Risk score: **'+r.riskScore+'/100** ('+me(r.band)+')','- Confidence: '+me(r.confidence),'','## Final assessment',me(r.finalAssessment),'','## Rule results'];
 if(!r.ruleResults.length)L.push('No rules fired.');
 r.ruleResults.forEach(f=>{L.push('### '+me(f.rule)+' (+'+f.contribution+')','- Confidence: '+me(f.confidence));f.evidenceExcerpts.forEach(e=>L.push('- Evidence: '+cs(e)));L.push('- Why it matters: '+me(f.whyItMatters),'- Action: '+me(f.recommendedAction),'')});
 L.push('## Extracted URLs');if(!r.extractedUrls.length)L.push('None.');r.extractedUrls.forEach(u=>L.push('- '+cs(u.url)+' x'+u.occurrences+' (line '+u.line+')'));
 L.push('','## Observed facts');r.observedFacts.forEach(x=>L.push('- '+me(x)));L.push('','## Unverified claims and limitations');r.unverifiedClaimsAndLimitations.forEach(x=>L.push('- '+me(x)));
 L.push('','## Recommended actions');r.recommendedActions.forEach(x=>L.push('- '+me(x)));return L.join('\n')}
function download(name,text,mime){const url=URL.createObjectURL(new Blob([text],{type:mime}));const a=h('a',{href:url,download:name});document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),500)}
const exportA=(a,fmt)=>{const r=report(a);fmt==='json'?download(a.id+'.json',JSON.stringify(r,null,2),'application/json'):download(a.id+'.md',toMD(r),'text/markdown');toast('Report exported ('+fmt.toUpperCase()+')')};

/* ---------- history ---------- */
const validEntry=e=>!!e&&typeof e==='object'&&typeof e.id==='string'&&typeof e.ts==='string'&&['email','url'].includes(e.type)&&Number.isFinite(e.score)&&e.score>=0&&e.score<=100&&Array.isArray(e.findings)&&e.findings.every(f=>f&&typeof f.rule==='string'&&Array.isArray(f.evidence))&&Array.isArray(e.facts||[]);
function parseImport(txt){try{const d=JSON.parse(txt);if(!Array.isArray(d))return{error:'Expected a JSON array of history entries.'};const ok=d.filter(validEntry);return{entries:ok.map(sanitize),skipped:d.length-ok.length}}catch(e){return{error:'Invalid JSON: '+e.message}}}
const sanitize=e=>({id:clip(e.id,40),ts:clip(e.ts,40),type:e.type,score:Math.round(e.score),band:clip(e.band||'',40),bandCls:['ok','cau','hi','vh'].includes(e.bandCls)?e.bandCls:'cau',verdict:clip(e.verdict||'',100),confidence:clip(e.confidence||'',100),label:clip(e.label||'',20),
 findings:e.findings.map(f=>({id:clip(f.id||'',30),rule:clip(f.rule,80),group:clip(f.group||'',20),weight:Number(f.weight)||0,conf:clip(f.conf||'',20),evidence:f.evidence.slice(0,4).map(x=>clip(x)),why:clip(f.why||'',250),action:clip(f.action||'',200)})),
 urls:(Array.isArray(e.urls)?e.urls:[]).slice(0,30).map(u=>({url:clip(u.url||'',200),count:Number(u.count)||1,line:Number(u.line)||1,findings:Array.isArray(u.findings)?u.findings.map(x=>clip(x,80)):[]})),
 facts:(e.facts||[]).slice(0,12).map(x=>clip(x,200)),unknowns:UNKNOWN,steps:(e.steps||[]).slice(0,5).map(x=>clip(x,200)),full:typeof e.full==='string'?clip(e.full,5000):undefined});
let hist=[];try{const raw=store.get('pg_hist');if(raw){const r=parseImport(raw);if(r.entries)hist=r.entries}}catch(e){}
const saveHist=()=>store.set('pg_hist',JSON.stringify(hist));
try{const c=store.get('pg_cfg');if(c){const d=JSON.parse(c);if(Array.isArray(d.shorteners))CFG.shorteners=d.shorteners.map(String).slice(0,200);if(Array.isArray(d.brands))CFG.brands=d.brands.map(String).slice(0,100);CFG.storeFull=!!d.storeFull}}catch(e){}
let current=null;

/* ---------- UI helpers ---------- */
let tt;function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('show'),2600)}
function modal(title,node){$('#m-title').textContent=title;$('#m-body').replaceChildren(node);$('#modal').showModal()}
const sev=w=>w>=18?'high':w>=10?'med':'low';
function list(items){return h('ul',items.map(x=>h('li',x)))}
function renderAnalysis(a,el,live){el.replaceChildren();
 const g=h('div',{class:'gauge',role:'img','aria-label':'Risk score '+a.score+' of 100'},h('div',{class:'fill '+a.bandCls}));g.firstChild.style.width=a.score+'%';
 el.append(h('div',{class:'card'},h('div',{class:'scorehead'},h('div',{class:'big '+a.bandCls},a.score,h('small','/100')),
  h('div',h('h3',a.verdict),h('p',{class:'muted'},'Band: '+a.band+' (heuristic label, not a probability of compromise).'),
  h('p',{class:'muted'},'Confidence: '+a.confidence+'. Risk is how many warning signs fired; confidence is how much input was available to judge them.'))),g,h('p',{class:'note'},NOTICE)));
 el.append(h('details',{open:''},h('summary','1. Observed facts'),list(a.facts)));
 const fs=h('details',{open:''},h('summary','2. Rule-based inferences ('+a.findings.length+')'));
 if(!a.findings.length)fs.append(h('p',{class:'muted'},'No rules fired. This does not show the message is safe.'));
 a.findings.forEach(f=>fs.append(h('div',{class:'finding '+sev(f.weight)},h('b',f.rule),' ',h('span',{class:'badge'},'+'+f.weight+' pts'),' ',h('span',{class:'badge'},'Confidence: '+f.conf),
  h('div',f.evidence.map(e=>h('div','Evidence: ',h('code',e)))),h('div',{class:'muted'},'Why it matters: '+f.why),h('div','Recommended: '+f.action))));
 el.append(fs);
 if(a.urls.length){const tb=h('tbody');a.urls.forEach(u=>tb.append(h('tr',h('td',h('code',clip(u.url,120))),h('td','line '+u.line),h('td',u.count>1?u.count+' (duplicate)':'1'),h('td',u.ok===false?'Malformed: '+(u.error||''):(u.findings&&u.findings.length?u.findings.join('; '):'No URL rules fired')))));
  el.append(h('details',{open:''},h('summary','Extracted URLs ('+a.urls.length+')'),h('div',{class:'scroll'},h('table',h('thead',h('tr',h('th','URL'),h('th','Location'),h('th','Count'),h('th','URL findings'))),tb))))}
 el.append(h('details',h('summary','3. Unknown or unverified'),list(a.unknowns)),h('details',{open:''},h('summary','4. Recommended next steps'),list(a.steps)));
 if(live){const sel=h('select',{'aria-label':'Your label'},['(no label)','phishing','legitimate','unsure'].map(x=>h('option',x))),cb=h('input',{type:'checkbox'});cb.checked=CFG.storeFull;
  el.append(h('div',{class:'card row'},h('label','Label ',sel),h('label',cb,' Also save full input (off by default)'),
   h('button',{class:'pri',onclick(){const e=JSON.parse(JSON.stringify(a));e.label=sel.value==='(no label)'?'':sel.value;if(cb.checked&&a.input)e.full=a.input;hist.unshift(sanitize(e));saveHist();toast('Saved to history'+(store.ok?'':' (session only; browser storage unavailable)'))}},'Save to history'),
   h('button',{onclick:()=>exportA(a,'json')},'Export JSON'),h('button',{onclick:()=>exportA(a,'md')},'Export Markdown')))}}

/* ---------- pages ---------- */
const PAGES=[['overview','Overview'],['email','Email Analyzer'],['url','URL Analyzer'],['history','Analysis History'],['training','Phishing Training Lab'],['reports','Reports'],['settings','Settings'],['about','About and Limitations']];
function show(id){PAGES.forEach(([k])=>{$('#p-'+k).hidden=k!==id});$$('#nav button').forEach(b=>b.setAttribute('aria-current',b.dataset.p===id?'page':'false'));
 ({overview:renderOverview,history:renderHistory,training:renderTraining,reports:renderReports,settings:renderSettings,about:renderAbout})[id]?.();$('#main').focus()}
PAGES.forEach(([k,l])=>$('#nav').append(h('button',{'data-p':k,onclick:()=>show(k)},l)));

function renderOverview(){const avg=hist.length?Math.round(hist.reduce((s,e)=>s+e.score,0)/hist.length):0;
 $('#p-overview').replaceChildren(h('h2','PhishGuard AI'),h('p','Explainable phishing-indicator analysis for suspicious emails and URLs. Every finding links to evidence from your input, and every score is the sum of documented rule weights.'),
 h('div',{class:'note'},'Current analysis method: local deterministic rules. No AI model is running and no data leaves your browser.'),
 h('div',{class:'stats'},[['Saved analyses',hist.length],['Average saved score',avg],['Training score',tr.answers.length?trainingScore(tr.answers,SCN.slice(0,tr.answers.length))+'/'+tr.answers.length:'not started']].map(([l,v])=>h('div',{class:'card stat'},h('b',v),l))),
 h('div',{class:'row'},h('button',{class:'pri',onclick:()=>show('email')},'Analyze an email'),h('button',{onclick:()=>show('url')},'Analyze a URL'),h('button',{onclick:()=>show('training')},'Open training lab')))}

const SAMPLE_EMAIL={name:'PayPal Support',addr:'support@paypa1-secure.example',org:'PayPal',reply:'help@mail-collector.example',known:'paypal.com',subj:'URGENT: account suspended',
 body:'Your account will be suspended within 24 hours. Verify your password immediately:\n<a href="http://203.0.113.9/login">https://www.paypal.com/verify</a>\nAlso see http://bit.ly/abc123 or http://203.0.113.9/login.'};
const EF={name:'e-name',addr:'e-addr',org:'e-org',reply:'e-reply',known:'e-known',subj:'e-subj',body:'e-body'};
$('#e-sample').onclick=()=>{for(const k in EF)$('#'+EF[k]).value=SAMPLE_EMAIL[k];toast('Synthetic sample loaded')};
$('#e-clear').onclick=()=>{for(const k in EF)$('#'+EF[k]).value='';$('#e-out').replaceChildren();current=null};
$('#e-run').onclick=()=>{const f={};for(const k in EF)f[k]=$('#'+EF[k]).value;const a=analyzeEmail({subject:f.subj,body:f.body,addr:f.addr,org:f.org,reply:f.reply,known:f.known});
 if(a.error){$('#e-out').replaceChildren(h('p',{class:'note',role:'alert'},a.error));return}if(CFG.storeFull)a.input=JSON.stringify(f);a.input=JSON.stringify({subject:f.subj,body:f.body});current=a;renderAnalysis(a,$('#e-out'),true)};
$('#u-sample').onclick=()=>{$('#u-url').value='http://paypal.com.account-verify.example:8443/login%2e/update.zip?next=http://x.example';$('#u-label').value='https://www.paypal.com'};
$('#u-run').onclick=()=>{const a=urlAnalysis($('#u-url').value,$('#u-label').value.trim());
 if(a.error){$('#u-out').replaceChildren(h('p',{class:'note',role:'alert'},a.error));return}a.input=JSON.stringify({url:$('#u-url').value});current=a;renderAnalysis(a,$('#u-out'),true);
 $('#u-out').prepend(h('p',{class:'note'},'A text-only analyzer cannot tell: whether the site is currently malicious, domain age, live reputation, real redirect destinations, server behavior, credential theft, or file malware.'))};

function renderHistory(){$('#h-note').textContent='Stored in this browser only (localStorage). '+(store.ok?'Storage is available.':'Storage unavailable: history lasts for this session only.')+' Clearing browser data deletes it. Full email text is not saved unless you opt in.';
 const q=$('#h-q').value.toLowerCase(),t=$('#h-t').value,tb=$('#h-body');tb.replaceChildren();
 const rows=hist.filter(e=>(!t||e.type===t)&&(!q||(e.id+' '+e.label+' '+e.findings.map(f=>f.rule).join(' ')).toLowerCase().includes(q)));
 if(!rows.length)tb.append(h('tr',h('td',{colspan:'8'},'No saved analyses match. Run an analysis and choose Save to history.')));
 rows.forEach(e=>tb.append(h('tr',h('td',e.id),h('td',new Date(e.ts).toLocaleString()),h('td',e.type),h('td',h('b',{class:e.bandCls},e.score)),h('td',e.findings.slice(0,2).map(f=>f.rule).join('; ')||'None'),h('td',e.label||'-'),h('td','Yes'),
  h('td',{class:'row'},h('button',{onclick:()=>{const d=h('div');renderAnalysis(e,d,false);if(e.full)d.append(h('details',h('summary','Saved input'),h('pre',{class:'mail'},e.full)));modal(e.id,d)}},'View'),h('button',{onclick:()=>exportA(e,'json')},'JSON'),h('button',{onclick:()=>exportA(e,'md')},'MD'),
   h('button',{onclick(){if(confirm('Delete '+e.id+'?')){hist=hist.filter(x=>x!==e);saveHist();renderHistory();toast('Entry deleted')}}},'Delete')))))}
$('#h-q').oninput=renderHistory;$('#h-t').onchange=renderHistory;
$('#h-clear').onclick=()=>{if(hist.length&&confirm('Delete all '+hist.length+' saved analyses?')){hist=[];store.del('pg_hist');renderHistory();toast('History cleared')}};
$('#m-close').onclick=()=>$('#modal').close();

/* ---------- training ---------- */
const SCN=[
{t:'Delivery fee',from:'Parcel Service <notice@parcel-track-help.example>',subj:'Package on hold: pay $1.99',body:'Your parcel is on hold. Pay the fee within 12 hours: http://203.0.113.9/pay\nCard number and CVV required.',answer:'sus',why:'Payment request via an IP-address link, deadline pressure, and a card/CVV request. Delivery services do not normally collect card data this way.',ev:['IP-address host','12-hour deadline','card number and CVV request']},
{t:'Password reset you requested',from:'Accounts <no-reply@accounts.example.com>',subj:'Reset your password',body:'You clicked "Forgot password" two minutes ago (this is the case in this scenario). Use https://accounts.example.com/reset to choose a new password. If this was not you, ignore this message.',answer:'legit',why:'You initiated the action, the link host matches the sender domain, no urgency, and no password is requested in the email. Still, you could type the address yourself.',ev:['user-initiated','sender and link domains match','no credentials requested']},
{t:'Vendor bank change',from:'Accounts Dept <billing@vendor-co.example>',subj:'Updated bank details',body:'Please use our new bank account for the next invoice. Reply to finance@vendor-co-pay.example. Do not call; we are traveling.',answer:'sus',why:'Bank-detail change, a different reply domain, and discouraging a phone check are classic invoice fraud signs.',ev:['bank-detail change','Reply-To domain differs','discourages verification call']},
{t:'Account closure',from:'Support <help@example-bank.test>',subj:'Final notice',body:'Your account will be closed within 24 hours. Confirm your password at https://example-bank.test.verify-login.example/',answer:'sus',why:'Closure threat plus a credential request, and the real registrable domain is verify-login.example, not example-bank.test.',ev:['closure threat','password request','misleading subdomain']},
{t:'Job offer',from:'HR <careers.recruit@freemail.example>',subj:'Offer: $90/hour, no interview',body:'You are hired. Send a copy of your ID and a $50 equipment deposit to begin.',answer:'sus',why:'Unrealistic pay, no interview, an ID request and an upfront deposit. Poor grammar was not needed to decide.',ev:['no interview','ID request','upfront payment']},
{t:'Internship selection',from:'Internship Cell <selection@intern-hub.example>',subj:'You are selected!',body:'Congratulations! Pay a refundable registration fee of 2000 to confirm your seat. Offer expires tonight.',answer:'sus',why:'You did not apply (assume), a fee is requested, and it expires tonight.',ev:['unexpected selection','fee request','deadline']},
{t:'Manager gift cards',from:'"Dana Lee (CEO)" <dana.lee.ceo@freemail.example>',subj:'Quick favor',body:'Buy 5 gift cards for a client and send me the codes. Keep this between us. I am in a meeting.',answer:'sus',why:'Authority impersonation from a free-mail address, gift-card codes, secrecy, and no normal approval.',ev:['free-mail address for a CEO','gift cards','secrecy']},
{t:'Shared document from a colleague?',from:'Sam Rao <sam.rao@mail.example>',subj:'Doc for you',body:'Sam shared "Q3 notes". Open: https://docs.example.net/d/8841',answer:'unsure',why:'Nothing demands urgency or credentials, but you cannot tell if Sam uses this address or if the domain is your company\'s. Verify with Sam first.',ev:['no urgency or credentials','sender and domain unverified']},
{t:'Newsletter',from:'Example News <news@example.org>',subj:'This week at Example',body:'Our weekly digest is ready: https://example.org/news. You can unsubscribe in your account settings.',answer:'legit',why:'Matching domains, no requests for data or money, no pressure. Not proof of safety, but no reason for suspicion.',ev:['matching domains','no requests','no pressure']},
{t:'Short message',from:'Unknown <sam@mail.example>',subj:'Hi',body:'Are you free to chat tomorrow?',answer:'unsure',why:'Too little information. It has no indicators, but also nothing to verify. Insufficient evidence is a valid answer.',ev:['no links','no requests','unknown sender']}];
const trainingScore=(ans,scn)=>ans.reduce((s,a,i)=>s+(scn[i]&&scn[i].answer===a?1:0),0);
let tr={answers:[]};
function renderTraining(){const el=$('#p-training'),i=tr.answers.length;el.replaceChildren(h('h2','Phishing Training Lab'),h('p',{class:'muted'},'All scenarios are fictional and use reserved example domains. Some are legitimate or ambiguous on purpose. Never enter real credentials here.'));
 const pr=h('progress',{max:SCN.length,value:i,'aria-label':'Progress'});el.append(h('p','Progress '+i+'/'+SCN.length+'. Score '+trainingScore(tr.answers,SCN)+'/'+i),pr);
 if(i>=SCN.length){const s=trainingScore(tr.answers,SCN);el.append(h('div',{class:'card'},h('h3','Finished: '+s+'/'+SCN.length),h('p',s>=8?'Strong. Keep remembering that insufficient evidence is a valid answer.':'Review the explanations. Look at sender domain, link host, requests, and pressure together.'),h('button',{class:'pri',onclick(){tr={answers:[]};renderTraining()}},'Restart training')));return}
 const s=SCN[i];el.append(h('div',{class:'card'},h('h3',s.t),h('p',h('b','From: '),s.from),h('p',h('b','Subject: '),s.subj),h('div',{class:'mail'},s.body),h('p','How would you classify this message?'),
  [['sus','Likely suspicious'],['legit','Likely legitimate'],['unsure','Insufficient evidence']].map(([v,l])=>h('button',{class:'opt',onclick(){tr.answers.push(v);const ok=v===s.answer;
   el.replaceChildren(h('h2','Phishing Training Lab'),h('div',{class:'card'},h('h3',{class:ok?'ok':'vh'},ok?'Correct':'Not quite'),h('p','Best answer: '+{sus:'Likely suspicious',legit:'Likely legitimate',unsure:'Insufficient evidence'}[s.answer]+'. You chose: '+l+'.'),h('p',s.why),h('p','Evidence to notice:'),list(s.ev),
    h('button',{class:'pri',onclick:renderTraining},i+1>=SCN.length?'See results':'Next scenario'),h('button',{onclick(){tr={answers:[]};renderTraining()}},'Restart')))}},l))))}

/* ---------- reports / settings / about ---------- */
function renderReports(){const el=$('#p-reports'),fi=h('input',{type:'file',accept:'.json,application/json','aria-label':'Import history JSON'});
 fi.onchange=()=>{const f=fi.files[0];if(!f)return;if(f.size>2e6){toast('File too large (2 MB max)');return}const r=new FileReader();r.onload=()=>{const p=parseImport(String(r.result));if(p.error){toast(p.error);return}hist=p.entries.concat(hist);saveHist();toast('Imported '+p.entries.length+', skipped '+p.skipped+' invalid')};r.readAsText(f)};
 el.replaceChildren(h('h2','Reports'),h('p',{class:'note'},NOTICE),h('p',current?'Latest analysis: '+current.id+' (score '+current.score+', '+current.verdict+')':'No analysis yet in this session. Run one from the Email or URL analyzer.'),
  h('div',{class:'row'},h('button',{class:'pri',disabled:current?null:'',onclick:()=>current&&exportA(current,'json')},'Export latest JSON'),h('button',{disabled:current?null:'',onclick:()=>current&&exportA(current,'md')},'Export latest Markdown'),
  h('button',{onclick(){if(!hist.length){toast('History is empty');return}download('phishguard-history.json',JSON.stringify(hist,null,2),'application/json')}},'Export all history (JSON)')),
  h('label','Import history JSON (validated; invalid entries skipped)',fi))}
function renderSettings(){const el=$('#p-settings'),sh=h('textarea',{rows:5,'aria-label':'Shorteners'}),br=h('textarea',{rows:4,'aria-label':'Brands'}),cb=h('input',{type:'checkbox'});sh.value=CFG.shorteners.join('\n');br.value=CFG.brands.join('\n');cb.checked=CFG.storeFull;
 const out=h('div');
 el.replaceChildren(h('h2','Settings'),h('p',{class:'muted'},'Browser storage: '+(store.ok?'available':'unavailable (session only)')),h('label','URL shortener domains (one per line)',sh),h('label','Example brand names for typosquatting checks (one per line; not exhaustive)',br),
  h('label',cb,' Save full input in history by default (off recommended)'),
  h('div',{class:'row'},h('button',{class:'pri',onclick(){const cl=t=>[...new Set(t.value.split('\n').map(x=>x.trim().toLowerCase()).filter(x=>/^[a-z0-9.-]+$/.test(x)))].slice(0,200);CFG.shorteners=cl(sh);CFG.brands=cl(br);CFG.storeFull=cb.checked;store.set('pg_cfg',JSON.stringify(CFG));toast('Settings saved')}},'Save settings'),
  h('button',{onclick(){if(hist.length&&confirm('Delete all history?')){hist=[];store.del('pg_hist');toast('History cleared')}}},'Clear history'),h('button',{onclick:()=>runTests(out)},'Run built-in tests')),
  h('p',{class:'muted'},'Tests run only when you click the button; results below come from that run.'),out)}
function renderAbout(){$('#p-about').replaceChildren(h('h2','About and Limitations'),h('p','PhishGuard AI highlights phishing warning signs using transparent local rules. The name reflects an AI-ready design; the current method is deterministic rules with no model.'),
 h('h3','Cannot determine'),list(UNKNOWN),h('h3','Also note'),list(['Static heuristics produce false positives and false negatives; attackers can avoid every rule.','Client-side code can be modified or bypassed. This is not an enterprise email security gateway.','Bands (0-24, 25-49, 50-74, 75-100) are heuristic labels, not validated probabilities.','Poor grammar is not scored.','Future AI hook: window.PhishGuardAI.explain(analysis) would call a backend you control. No API keys belong in client code. It is disabled and unused now.']))}
window.PhishGuardAI={enabled:false,async explain(){throw new Error('No AI backend configured. Local rules only.')}};

/* ---------- built-in tests (run on demand) ---------- */
function runTests(out){const bodyOk='Hi team, the agenda for Thursday is ready in the shared calendar. See you there. Thanks, Priya';
 const emp=analyzeEmail({}),T=[
 ['1 Empty email input',()=>!!emp.error],
 ['2 Valid email, no strong signs',()=>{const a=analyzeEmail({subject:'Agenda',body:bodyOk,addr:'priya@example.org',known:'example.org'});return a.score<25&&a.verdict==='No strong phishing indicators found'}],
 ['3 Urgent phishing-style message',()=>analyzeEmail({subject:'URGENT',body:'Verify your password immediately or your account will be suspended.',addr:'a@b.example'}).score>=25],
 ['4 Sender / claimed org mismatch',()=>analyzeEmail({subject:'Hi',body:bodyOk,addr:'help@secure-pay.example',org:'PayPal'}).findings.some(f=>f.id==='mail.orgmismatch')],
 ['5 URL with IP address',()=>analyzeURL('http://192.0.2.5/login').findings.some(f=>f.id==='url.ip')],
 ['6 Misleading subdomain',()=>analyzeURL('https://paypal.com.verify-login.example/a').findings.some(f=>f.id==='url.subdomain')],
 ['7 Invalid URL handled',()=>analyzeURL('http://').ok===false&&analyzeURL('not a url ::').ok===false],
 ['8 Punycode / IDN host',()=>analyzeURL('http://xn--pple-43d.example/').findings.some(f=>f.id==='url.punycode')&&analyzeURL('http://\u0430pple.example/').findings.some(f=>f.id==='url.punycode')],
 ['9 Multiple links with duplicate',()=>{const u=extractURLs('a http://x.example/1 b http://y.example/2, c http://x.example/1.');return u.length===2&&u[0].count===2}],
 ['10 Ambiguous email = insufficient',()=>analyzeEmail({subject:'Hi',body:'Are you free to chat tomorrow?'}).verdict.startsWith('Insufficient')],
 ['11 Malformed import rejected',()=>!!parseImport('{bad').error&&!!parseImport('{}').error&&parseImport('[{"id":1},{}]').entries.length===0],
 ['12 Report export content',()=>{const r=report(analyzeEmail({subject:'URGENT',body:'Verify your password now `x` <b>',addr:'a@b.example'}));const m=toMD(r);return JSON.parse(JSON.stringify(r)).notice===NOTICE&&m.includes(NOTICE.replace(/\./g,'\\.').slice(0,10))&&new Blob([m]).size>0}],
 ['13 History storage unavailable',()=>{store.sim=true;try{store.set('t','1');return store.get('t')==='1'}finally{store.sim=false;store.ok=true;delete mem.t}}],
 ['14 Training score calculation',()=>trainingScore(['sus','legit','x'],[{answer:'sus'},{answer:'sus'},{answer:'x'}])===2],
 ['15 Identical inputs, identical scores',()=>{const i={subject:'URGENT',body:'Verify your password at http://192.0.2.5/x',addr:'a@b.example'},a=analyzeEmail(i),b=analyzeEmail(i);return a.score===b.score&&JSON.stringify(a.findings)===JSON.stringify(b.findings)}]];
 const tb=h('tbody');let p=0;T.forEach(([n,f])=>{let ok=false;try{ok=!!f()}catch(e){}p+=ok;tb.append(h('tr',h('td',n),h('td',{class:ok?'ok':'vh'},ok?'PASS':'FAIL')))});
 out.replaceChildren(h('p','Executed '+new Date().toLocaleString()+': '+p+'/'+T.length+' passed'),h('table',h('thead',h('tr',h('th','Test'),h('th','Result'))),tb))}
show('overview');
